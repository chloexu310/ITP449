#Yanyu Xu
#ITP_449, Spring 2020
#HW01
#Question 1



def main():
    userInput = input("Enter your password:")
    print("Your password is", len(userInput), "characters long")




main()